###################
Full example with IonAuth + Codeigniter 3
###################

Clone this repository, execute the sql.txt in your dbms favorite, open to the url /auth and enjoy.

*********
Tutorial
*********

-  `Unodepiera <http://uno-de-piera.com>`_